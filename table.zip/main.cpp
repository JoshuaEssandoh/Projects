/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    char names[4][100]={"Robin","Arthur","Cinderella","SnowWhite"};
    int grades[4][2]={
        {88,93},
        {93,89},
        {0,3},
        {99,225}
    };
    cout<<left<<setw(8)<<"Name"<<setw(12)<<"Course 1"<<setw(12)<<"Course 2"<<endl<<"___________________________________"<<endl;
    for(int i=0;i<4;i++){
        cout<<setw(12)<<names[i];
        for(int n=0;n<2;n++){
            cout<<setw(12)<<grades[i][n];
        }
        cout<<endl;
    }
    
    return 0;
}