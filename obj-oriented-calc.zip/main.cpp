/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
class Calc {
    double Num1;
    double Num2;
    public:
    double Add();
    double Sub();
    double Mult();
    double Div();
    void Set_Num1(double N)
    {
        Num1 = N;
    }
    double Get_Num1()
    {
        return Num1;
    }
    void Set_Num2(double N)
    {
        Num2 = N;
    }
    double Get_Num2()
    {
        return Num2;
    }
    
    Calc(double N1, double N2);
    Calc();
};

Calc :: Calc(double N1,double N2)
{
    Set_Num1(N1);
    Set_Num2(N2);
    
}

Calc :: Calc()
{
    int N1;
    int N2;
    cout<<"Please input Numbers 1 and 2 respectively: "<<endl;
    cin>>N1;
    cin>>N2;
    Set_Num1(N1);
    Set_Num2(N2);
}

double Calc::Add()
{
    return Num1+Num2;
}

double Calc::Sub()
{
    return Num1-Num2;
}

double Calc::Mult()
{
    return Num1*Num2;
}

double Calc::Div()
{
    return Num1/Num2;
}
int main()
{
    Calc Cal1(8,7);
    cout<<Cal1.Mult()<<endl;
    Calc Cal2;
    cout<<Cal2.Div()<<endl;

    return 0;
}