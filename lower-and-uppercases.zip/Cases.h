#include<iostream>
using namespace std;
double lConverter(char letter)
{
   return letter+32;
}
double uConverter(char letter)
{
    return letter-32;
}