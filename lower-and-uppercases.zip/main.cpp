/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include "Cases.h"
using namespace std;
int main()
{
    int x=0;
    char letter;
    int back;
    do{
    cout<<"What letter do you want to change?: ";
    cin>>letter;
    if(letter>=65 && letter<=90){
    letter = lConverter(letter);
    cout<<"The alternate version is: "<<letter<<endl;
    } else if(letter>=97 && letter<=122){
        letter = uConverter(letter);
        cout<<"The alternate version is: "<<letter<<endl;
    }
    else if(letter==48){
        break;
    }
    else{
        cout<<"Please input a number"<<endl;
        continue;
    }
    x++;
    cout<<"Do you want to continue? 1=no, other number=yes: ";
    cin>>back;
    
}while(back!=1);
    cout<<"You ran the function "<<x<<" times";
    return 0;
}
