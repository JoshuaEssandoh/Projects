/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.
cin>>Decimals[0]>>endl>>Decimals[2]>>endl>>Decimals[3]>>endl>>Decimals[4]>>endl>>Decimals[5]>>endl>>Decimals[6]>>endl>>Decimals[7]>>endl>>Decimals[8]>>endl>>Decimals[9]>>endl

*******************************************************************************/
#include <iostream>
using namespace std;
int main()
{
    double Decimals[10];
    
    cout<<"Please input 10 decimals"<<endl;
    int i;
    for(i=0;i<10;i++){
        cin>>Decimals[i];
    }
    double x=0;
    for(int i=0;i<10;i++){
        x=x+Decimals[i];
    }
    double answer=x/10;
    cout<<"The average is: "<<answer;

    return 0;
}
