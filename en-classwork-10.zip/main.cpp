/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <fstream>

using namespace std;

class Person {
    public:
    string name;
    void printName(){
        cout << name << "'s ";
    }
};

class Course{
    public:
    int HW1;
    int HW2;
    int Q1;
    int Q2;
    int Exam;
    double Final;
    virtual void calculateFinal(){
        
        Final = HW1 + HW2 + Q1 + Q2 + Exam;
        Final = Final/5;
        cout<<Final<<endl;
    }
    
};

class Student:public Person, public Course
{
    public:
    void calculateFinal()
    {
      Final =(((HW1 + HW2) / 2)*0.2) + (((Q1 + Q2) / 2)*0.3) + (Exam*0.5);
         cout<<"final grade is "<<Final<<endl;    
    }
};

int main()
{
    int i = 0;
    Student stu[4];
    ifstream myFile("class.txt");
    while(!myFile.eof()){
        myFile >> stu[i].name >> stu[i].Q1 >> stu[i].Q2 >> stu[i].HW1 >> stu[i].HW2 >> stu[i].Exam;
        i++;
    }

    
    for(i = 0; i < 4; i++){
        stu[i].printName();
        stu[i].calculateFinal();
    }

    return 0;
}