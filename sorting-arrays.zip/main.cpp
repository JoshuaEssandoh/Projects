/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <stdlib.h>
#include <ctime>
#include <fstream>
using namespace std;

int main()
{
    int x=0;
    srand(time(0));
    x++;
    int i;
    int array[20];
    for(i=0;i<20;i++){
    array[i] = 1 + rand()%100;
    cout<<array[i]<<endl;
    }
    
    
    
    
    ofstream MyFile("Array.txt");
    MyFile<<array;
    
    for(int n=0;n<=19;n++){
        for(int b=1;b<=20;b++){
             ifstream MyFile("Array.txt");
             if(array[b]<array[b - 1]){
                 int temp;
                 temp=array[b];
                 array[b]=array[b - 1];
                 array[b - 1]=temp;
             }
        }
    }
    
    return 0;
}