/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int main()
{
    double base,power,count,total=1;
    cout<<"please input your base: ";
    cin>>base;
    cout<<"please input your power: ";
    cin>>power;
    if(power==0) cout<<"1";
    if(power>=1) 
    {
        for(int count=1;count<=power;count++) total=total*base;
        cout<<total;
        
    }
    if(power<0)
    {
        for(int count=-1;count>=power;count--) total=total*base;
        cout<<1/total;
    }
    return 0;

}
