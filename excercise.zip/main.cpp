/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;
int main()
{
    string name,lasname;
    double ID;
    
    int x;
    ofstream myFile("student_database.txt");
    
    if(!myFile){
        cout<<"File could not open!"<<endl;
        exit(1);
    }
    do{
        x++;
        cout<<"input your first name: ";
    cin>>name;
    cout<<"input your last name: ";
    cin>>lasname;
    cout<<"Input your Student ID number: ";
    cin>>ID;
        }while(x<=10);
    myFile<<cout<<left<<setw(10)<<name<<setw(10)<<lasname<<setw(6)<<ID<<endl;
    myFile.close();
    return 0;
}
