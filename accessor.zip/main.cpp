/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <fstream>
using namespace std;

class Vehicle {
        int passengers;
        int fuelcap;
        int mpg;
        public:
        int weight;
        int wheels;
        
        int Get_passengers()
        {
            return passengers;
        }
        void Set_passengers(int np)
        {
            passengers = np;
        }
    };   
int main()
{
    int n = 0;
    int num;
    Vehicle golfcart[2];
    golfcart[0].Set_passengers(20);
    cout<<golfcart[0].Get_passengers()<<endl;
    ofstream myFile("File.txt");
    myFile << 20;
    ifstream myFile("File.txt");
    while(!myFile.eof())
    {
    myFile >> num;
    golfcart[n].Set_passengers(num);
    cout<<golfcart[n].Get_passengers()<<endl;
    num = 0;
    n++;
    };
    ofstream myFile("File.txt");
    myFile << 20;
    return 0;
}
