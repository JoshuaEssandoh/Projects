/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<math.h>
using namespace std;
int power(double I1,double I2){
        return pow(I1,I2);
    }
short unsigned int power2(double I3,double I4){
    return pow(I3,I4);
}
short int power3(double I5,double I6){
    return pow(I5,I6);
}
long int power4(double I7,double I8){
    return pow(I7,I8);
}

int main()

{
    int p;
    
    
    for(p=1;p<=20;p++)cout<<p<<"    "<<power(2,p)<<endl;
    
    cout<<
    
}
