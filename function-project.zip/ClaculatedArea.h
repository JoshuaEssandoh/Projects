#include<iostream>
using namespace std;
double CalculatedArea(double width,double length)
{
    double area;
    area=length*width;
    cout<<"area is: "<<area;
    return area;
}