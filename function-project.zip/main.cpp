#include "ClaculatedArea.h"

int main()
{
    double area;
    area=CalculatedArea(4.5,6.5);
    cout<<area;
    return 0;
}

