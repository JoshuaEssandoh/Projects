/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <fstream>
#include <iomanip>
#include "Calculator.h"
using namespace std;

int main()
{
string st_name;

int in_password;

string confirmation="yes";

string Username[10];

int Password[10];

int i=0;

ifstream myFile("Information.txt");

while(!myFile.eof()){

  myFile >> Username[i] >> Password[i];

  i++;

}
do{
cout<<"Enter Username: ";

cin>>st_name;

cout<<"Enter in Password: ";

cin>>in_password;

for(int i=0;i<10;i++){

  if(st_name == Username[i]&&in_password == Password[i]){
    Calculator();
    exit(1);
  }
  else{
      cout<<"entered an invalid user ID or/and pin number"<<endl;
      break;
  }
}
}while(st_name!=Username[i]||in_password!=Password[i]);
}