#include <iostream>
#include <math.h>

using namespace std;

double Add(double n1, double n2)
{
    return n1+n2;
}

double Subt(double n1, double n2)
{
    return n1-n2;
}

double Mult(double n1, double n2)
{
    return n1*n2;
}

double Div(double n1, double n2)
{
    return n1/n2;
}

double sqt(double n1)
{
    return sqrt(n1);
}

double power(double n1,double n2)
{
    return pow(n1,n2);
}
void Calculator()
{
    int choice=0;
    double n1=0,n2=0;
    cout<<"Please, enter the type of operation: 1-Add, 2-Subt, 3-Mult, 4-Div, 5-sqrt, 6-pow";
    cin>>choice;
    
    if(choice==1){
        cout<<"input num1 and num2";
        cin>>n1>>n2;
        cout << n1 <<" + "<<n2 <<" = "<<Add(n1,n2) << endl;
    }
    
    if(choice==2){
        cout<<"input num1 and num2: ";
        cin>>n1>>n2;
        cout << n1 <<" - "<<n2 <<" = "<<Subt(n1,n2) << endl;
    }
    
    if(choice==3){
        cout<<"input num1 and num2: ";
        cin>>n1>>n2;
        cout << n1 <<" * "<<n2 << " = "<<Mult(n1,n2) << endl;
    }
    if(choice==4){
        cout<<"input numerator and then denominator:";
        cin>>n1>>n2;
        cout << n1 <<"/"<<n2 << " = "<<Div(n1,n2) << endl;
    }
    if(choice==5){
        cout<<"input a number: ";
        cin>>n1;
        cout <<"The square root of "<<n1<<" is "<<sqt(n1)<<endl;
    }
    if(choice==6){
        cout<<"input a base and an exponent: ";
        cin>>n1>>n2;
        cout<<"The answer is: "<<power(n1,n2)<<endl;
    }
    
}