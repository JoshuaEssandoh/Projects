/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <fstream>
#include <iomanip>
#include <stdlib.h>
using namespace std;



class ATM
{
protected:
  int account;
  double balance;

public:
  int PIN;
  double money;
  virtual void Deposit (double n);
  virtual void Withdraw (double n);
  virtual double Inquiry ();


    ATM (int acc, double Ibal);
    ATM ();
   ~ATM ();
  void Set_Account (int np)
  {
    account = np;
  }
  int Get_Account ()
  {
    return account;
  }
  int Get_Balance ()
  {
    return balance;
  }
  void Set_Balance (int np)
  {
    balance = np;
  }
};

ATM::ATM (int acc, double Ibal)
{
  cout << "Welcome to Jumping Joshua's Bank!" << endl;
  account = acc;
  balance = Ibal;
}

ATM::ATM ()
{
  cout << "Welcome!" << endl;
}

ATM::~ATM ()
{
  cout << "Welgo! Please jump back again!" << endl;
}

void
ATM::Deposit (double n)
{
  balance = n + balance;
}

void
ATM::Withdraw (double n)
{
  balance = balance - n;
  if (balance < 0)
    {
      balance = balance + n;
      cout << "Please remove the correct amount.";
    }
}

double
ATM::Inquiry ()
{
  return balance;
}

class CheckingAccount:public ATM
{
public:
  CheckingAccount ();
  ~CheckingAccount ();
};

CheckingAccount::CheckingAccount ()
{
  cout << "You have one checking account..." << endl;
}

CheckingAccount::~CheckingAccount ()
{
  cout << "Signing out of your checking account..." << endl;
}


class SavingsAccount:public ATM
{
public:
  SavingsAccount ();
  ~SavingsAccount ();
  void GainLoss ()
  {
    double num1;
    int num2;
    int per;
      srand (time (0));
      num1 = rand () % 50;
      num1 = num1 / 100;
      per = balance * num1;
      num2 = rand () % 2;
    if (num2 == 0)
      {
	balance = per + balance;
	cout << "You gained " << per << "$!" << endl <<
	  "Your current balance is " << balance << "$" << endl;

      }
    else
      {
	balance = balance - per;
	cout << "You lost " << per << "$." << endl <<
	  "Your current balance is " << balance << "$" << endl;
      }
  }
  void Deposit (double n)
  {
    balance = n + balance;
    GainLoss ();
  }
  void Withdraw (double n)
  {
    balance = balance - n;
    if (balance < 0)
      {
	balance = balance + n;
	cout << "Please remove the correct amount.";
      }
    GainLoss ();
  }
  double Inquiry ()
  {
    GainLoss ();
    return balance;
  }
};


SavingsAccount::SavingsAccount ()
{
  cout << "You have one savings account..." << endl;
}

SavingsAccount::~SavingsAccount ()
{
  cout << "Signing out of your savings account..." << endl;
}

class User
{
public:
  int pin;
  int UserID;
  CheckingAccount *CheckingAcc = new CheckingAccount;
  SavingsAccount *SavingsAcc = new SavingsAccount;
};


User *CheckUser (int acc, int pin, User * u, int size)
{
label:
  int i = 0;
  while (i < size)
    {
      if (acc == (u + i)->UserID)
	{
	  if (pin == (u + i)->pin)
	    {
	      break;
	    }
	}
      i++;
    };
  if (i < size)
    {
      cout << "Great!" << endl;
      return (u + i);
    }

  else
    {
      cout<<"Please try again"<<endl;
      goto label;
    }
}



User *ProcessChecking(User *u, int select)
{
  double money;
  if (select == 3)
    {
      cout << "Please input the amount you wish to deposit. " << endl;
      cin >> money;
      u->CheckingAcc->Deposit(money);
      cout << "$" << u->CheckingAcc->Get_Balance() << endl;
    }
  
  else if (select == 2)
    {
      cout << "Please input the amount you wish to withdraw. " << endl;
      cin >> money;
      u->CheckingAcc->Withdraw (money);
      cout << "$" << u->CheckingAcc->Get_Balance () << endl;
    }
  
  else if (select == 1)
    {
      cout << u->CheckingAcc->Inquiry () << "$" << endl;

    }
  return u;
}

User *ProcessSavings(User *u, int select)
{
  double money;
  if (select == 3)
    {
      cout << "Please input the amount you wish to deposit. " << endl;
      cin >> money;
      u->SavingsAcc->Deposit(money);
      cout << "$" << u->SavingsAcc->Get_Balance()<< endl;
    }
  
  else if (select == 2)
    {
      cout << "Please input the amount you wish to withdraw. " << endl;
      cin >> money;
      u->SavingsAcc->Withdraw (money);
      cout << "$" << u->SavingsAcc->Get_Balance() << endl;
    }
  
  else if (select == 1)
    {
      cout << u->SavingsAcc->Inquiry() << "$" << endl;

    }
  return u;
}


User *DoTransaction(User *u, string st)
{
  int select;
  double money;
  string confirmation = "yes";
  for (; confirmation == "yes";)
    {
      cout << "What type of transaction do you want to apply?" << endl <<
	"Deposit - 3, Withdraw - 2, Inquiry - 1" << endl;
      cin >> select;
      if (st == "Check")
	{
	  ProcessChecking (u, select);
	}

      else if (st == "Save")
	{
	  ProcessSavings (u, select);
	}

      cout << "Do you wish to continue? yes or no: " << endl;
      cin >> confirmation;
    }
  return u;
}
void WriteUserData(User *u, int size)
{
  int i = 0;
  ofstream myFile2 ("accounts.txt");
  while (i < size)
    {
      myFile2<<(u + i)->UserID<< " "
      <<(u + i)->pin << " " 
      << (u +i)->CheckingAcc->Get_Account()<< "  " 
      << (u + i)->CheckingAcc->Get_Balance() << "  " 
      << (u + i)->SavingsAcc->Get_Account () << "  " 
      << (u + i)->SavingsAcc->Get_Balance () << endl;
      i++;
    };
  cout << "Your information has been updated. " << endl;

}

void OpenAccount(User *u, int size)
{
    int ID, PIN, Cacc, Sacc;
    int i = 0;
    double Cbal, Sbal;
    cout<<"Please input your ID and PIN"<<endl;
    cin>>ID>>PIN;
    cout<<"Please input your checking account and checking balance"<<endl;
    cin>>Cacc>>Cbal;
    cout<<"Please input your savings account and savings balance"<<endl;
    cin>>Sacc>>Sbal;
    (u + size)->UserID = ID;
    (u + size)->pin = PIN;
    (user + size)->CheckingAcc->Set_Account(Cacc);
    (user + size)->CheckingAcc->Set_Balance(Cbal);
    (user + size)->SavingsAcc->Set_Account(Sacc);
    (user + size)->SavingsAcc->Set_Balance(Sbal);
    
    
    myFile2.open("accounts.txt");
    while (i <= size)
    {
      myFile2<<(u + i)->UserID<< " "
      <<(u + i)->pin << " " 
      << (u +i)->CheckingAcc->Get_Account()<< "  " 
      << (u + i)->CheckingAcc->Get_Balance() << "  " 
      << (u + i)->SavingsAcc->Get_Account () << "  " 
      << (u + i)->SavingsAcc->Get_Balance () << endl;
      i++;
    };
     myFile2.close();
     cout << "Your information has been updated. " << endl;

}

void CloseAccount(User *u, int size){
    int acc, pin, h;
    int i = -1;
    cout<<"Please enter the UserID and PIN of the account you want to close"<<endl;
    cin>>acc>>pin;
    for (h = 0; h < size; h++)
	{
    if(CheckUser(acc, pin, user, n) == (user + h))break;
    else{
        cout<<"Please try another time"<<endl;
        exit;
    } 
	}
	while (i < size)
    {
      i++;
      if(i == h)continue;
      myFile2.open("accounts.txt");
      myFile2<<(u + i)->UserID<< " "
      <<(u + i)->pin << " " 
      << (u +i)->CheckingAcc->Get_Account()<< "  " 
      << (u + i)->CheckingAcc->Get_Balance() << "  " 
      << (u + i)->SavingsAcc->Get_Account () << "  " 
      << (u + i)->SavingsAcc->Get_Balance () << endl;
    };
    myFile2.close();
     cout << "Your information has been updated. " << endl;

}

int main()
{

  int n;
  int acc;
  double bal;
  int pin;
  int num1;
  double num2;
  int num3;
  double num4;
  string string, conf;


  int i = 0;
  User user[100];
  //below is the ReadUserData function
  ifstream myFile ("accounts.txt");
  while (!myFile.eof ())
    {
      myFile >> (user + i)->UserID >> (user + i)->pin >> num1 >> num2 >> num3 >> num4;
      (user + i)->CheckingAcc->Set_Account(num1);
      (user + i)->CheckingAcc->Set_Balance(num2);
      (user + i)->SavingsAcc->Set_Account(num3);
      (user + i)->SavingsAcc->Set_Balance(num4);
      i++;
    }
    //n is now the size
    n = i;
  i = 0;
    int h;
  while(0 == 0)
    {
      cout << "Please enter in your account number: " << endl;
      cin >> acc;
      cout << "Please enter your PIN number. " << endl;
      cin >> pin;
      for (h = 0; h < n; h++)
	{
    if(CheckUser(acc, pin, user, n) == (user + h))break;
	}
	if(h < n)break;
    }
    
    WriteUserData (user, n);
    
	  User *CurrentUser = new User;
	  CurrentUser = CheckUser(acc, pin, user, n);
	  cout << "Which account do you wish to access?" << endl 
	  <<"Check for Checkings Account" << endl 
	  << "Save for Savings" << endl;
	  
	  cin >> string; 
	  if (string == "Check"){DoTransaction (CurrentUser, string);}
	  
	  else if (string == "Save")
	  {
	  CurrentUser->SavingsAcc->GainLoss();
	  DoTransaction (CurrentUser, string);
	  }
    cout<<"Do you want to open or close an account? Type 'open' or 'close' or 'no'"<<endl;
    cin>>conf;
    
    if(conf == "open")OpenAccount(User, n);
    else if(conf == "close")CloseAccount(User, n);
	  WriteUserData (user, n); 
	  return 0;
    
}
