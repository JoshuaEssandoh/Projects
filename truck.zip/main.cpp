/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <algorithm>

using namespace std;

class Vehicle {
    public:
    
    string model;
    int passengers;
    int fuelcap;
    double mpg;
    double cost;
    
    int fpp();
    int fuelcost();
};

  int Vehicle::fpp()
    {
        int i;
        int n;
        i = fuelcap / passengers;
        n = 100/mpg;
        
        return i * n;
    }
    
    int Vehicle::fuelcost()
    {
        return fpp() * cost;
    }
    
int main()
{
    Vehicle Car;
    Vehicle Bus;
    Vehicle Truck;
    Vehicle Airplane;
    
    cout << "Please enter the following values for a car: fuelcap, mpg, passengers, cost, model. "<<endl;
    cin>>Car.fuelcap;
    cin>>Car.mpg;
    cin>>Car.passengers;
    cin>>Car.cost;
    cin>>Car.model;
    
    cout<<"The fuel cost per passenger per 100 miles for your car is: "<<Car.fuelcost();
    
    cout << "Please enter the following values for a Bus: fuelcap, mpg, passengers, cost, model. "<<endl;
    cin>>Bus.fuelcap;
    cin>>Bus.mpg;
    cin>>Bus.passengers;
    cin>>Bus.cost;
    cin>>Bus.model;
    
    cout<<"The fuel cost per passenger per 100 miles for your bus is: "<<Bus.fuelcost();
    
    cout << "Please enter the following values for a Truck: fuelcap, mpg, passengers, cost, model. "<<endl;
    cin>>Truck.fuelcap;
    cin>>Truck.mpg;
    cin>>Truck.passengers;
    cin>>Truck.cost;
    cin>>Truck.model;
    
    cout<<"The fuel cost per passenger per 100 miles for your truck is: "<<Truck.fuelcost();
    
    cout << "Please enter the following values for a airplane: fuelcap, mpg, passengers, cost, model. "<<endl;
    cin>>Airplane.fuelcap;
    cin>>Airplane.mpg;
    cin>>Airplane.passengers;
    cin>>Airplane.cost;
    cin>>Airplane.model;
    
    cout<<"The fuel cost per passenger per 100 miles for your car is: "<<Airplane.fuelcost();
    
    int eff;
    eff = min({Car.fuelcost(),Bus.fuelcost(),Truck.fuelcost(),Airplane.fuelcost()});
    
    if(Car.fuelcost() == eff)cout << "The most efficient vehicle is the "<<Car.model<<"!";
    else if(Bus.fuelcost() == eff)cout << "The most efficient vehicle is the "<<Bus.model<<"!";
    else if(Truck.fuelcost() == eff)cout << "The most efficient vehicle is the "<<Truck.model<<"!";
    else if(Airplane.fuelcost() == eff)cout << "The most efficient vehicle is the "<<Airplane.model<<"!";
    
   
    return 0;
}
