/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<iomanip>
#include<math.h>
using namespace std;
double Interestpaid(double rate,double principal)
{
    return rate*principal;
}

double PrincipalPay(double interest,double Monthly)
{
    return Monthly-interest;
}


double MonthlyPay(double P,double i, double n,double escrow)
{
    double m=1 + i;
    double g=pow(m,n);
    double t = g - 1;
    double o = P*((i*g)/(t)) + escrow;
    return o;
}

int main()
{
    double principal;
    double interest;
    double escrow;
    double term;
    double month=1;
    cout<<"Please enter the Principal amount"<<endl;
    cin>>principal;
    cout<<"Please enter the yearly interest amount in decimals"<<endl;
    cin>>interest;
    cout<<"Please enter the escrow amount"<<endl;
    cin>>escrow;
    cout<<"Please enter the term amount in years"<<endl;
    cin>>term;
    term=term*12;
    cout<<left<<setw(7)<<"Month"<<setw(18)<<"Monthly Payment"<<setw(8)<<"Escrow"<<setw(18)<<"Principal Paid"<<setw(16)<<"Interest Paid"<<"Principal Remaining";
    double minterest = interest/12;
    
    double monthly=MonthlyPay(principal,minterest,term,escrow);
    do{
       month++;
       double n=Interestpaid(minterest,principal);
       double m=PrincipalPay(n,monthly);
       cout<<endl<<endl;
       cout<<setw(7)<<month<<setw(18)<<monthly<<setw(8)<<escrow<<setw(18)<<m<<setw(16)<<n<<principal<<endl;
       principal=principal-m;
       }while(month<=term + 1&&principal>=0);

    return 0;
}


