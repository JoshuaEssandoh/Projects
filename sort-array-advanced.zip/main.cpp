/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>



#include <iostream>
#include <stdlib.h>
#include <ctime>
#include <cstdlib>
using namespace std;

void sort_array(int g[],int size)
{
     int n;
    
    
    for(n=0;n<size - 1;n++){
        for(int f=0;f<(size - 1) - n; f++){
            if(g[f] > g[f + 1])swap(g[f],g[f + 1]);
            
        }
    }
    
     for(int i=0;i<size;i++) cout<<g[i]<<" "; 
}





int main()
{
   srand(time(0));
    int i;
    double total = 0;
    int b;
    cout<<"How many randomly generated numbers do you wish to have?: ";
    cin>>b;
    int array[b];
    
    for(i=0;i<b;i++){
    array[i] = rand()%100;
    cout<<array[i]<<" ";
    }
    
    for(i=0;i<b;i++)total = total + array[i];
    total = total/b;
    
    cout << endl << "The mean for this randomly generated array is: "<<total<<endl;
    
    
    
    
    cout << "The sorted out version of the random array is: "<<endl;
       sort_array(array,b);
        
        char a;
        cout<<a;
    
}
