/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <cstring>
using namespace std;


int main()
{
    char str1[50]="What is my first name?";
    char stra1[50]="Joshua";
    char strb1[50];
    
    char str2[50]="Finish the sentence: Equivalence _________";
    char stra2[50]="Principle";
    char strb2[50];
    
    char str3[50]="What country is the World Cup taking place in?";
    char stra3[50]="Qatar";
    char strb3[50];
    
    char str4[50]="What city is GSST located in?";
    char stra4[50]="Hampton";
    char strb4[50];
    
    char str5[50]= "What is the name of our strand?";
    char stra5[50]="Engineering";
    char strb5[50];
    
    cout<<str1<<endl;
    cin>>strb1;
    if(strcmp(strb1,stra1)==0) cout<<"Correct!"<<endl;
    
        else{
        for(int i=0;i<6;i++){
             cout<<"incorrect"<<endl;
            cout<<stra1[i]<<endl;
            cin>>strb1;
            if(strcmp(strb1,stra1)==0){
              cout<<"Correct!"<<endl;
              break;
            } 
        }
    }
    
     cout<<str2<<endl;
    cin>>strb2;
    if(strcmp(strb2,stra2)==0) cout<<"Correct!"<<endl;
    
        else{
        for(int i=0;i<9;i++){
             cout<<"incorrect"<<endl;
            cout<<stra2[i]<<endl;
            cin>>strb2;
            if(strcmp(strb2,stra2)==0){
              cout<<"Correct!"<<endl;
              break;
            } 
        }
    }


 cout<<str3<<endl;
    cin>>strb3;
    if(strcmp(strb3,stra3)==0) cout<<"Correct!"<<endl;
    
        else{
        for(int i=0;i<6;i++){
             cout<<"incorrect"<<endl;
            cout<<stra3[i]<<endl;
            cin>>strb3;
            if(strcmp(strb3,stra3)==0){
              cout<<"Correct!"<<endl;
              break;
            } 
        }
    }
    
    
 cout<<str4<<endl;
    cin>>strb4;
    if(strcmp(strb4,stra4)==0) cout<<"Correct!"<<endl;
    
        else{
        for(int i=0;i<7;i++){
             cout<<"incorrect"<<endl;
            cout<<stra4[i]<<endl;
            cin>>strb4;
            if(strcmp(strb4,stra4)==0){
              cout<<"Correct!"<<endl;
              break;
            } 
        }
    }
    
 cout<<str5<<endl;
    cin>>strb5;
    if(strcmp(strb5,stra5)==0) cout<<"Correct!"<<endl;
    
        else{
        for(int i=0;i<11;i++){
             cout<<"incorrect"<<endl;
            cout<<stra5[i]<<endl;
            cin>>strb5;
            if(strcmp(strb5,stra5)==0){
              cout<<"Correct!"<<endl;
              break;
            } 
        }
    }
    
    cout<<"Congratulations!!!!"<<endl;
    

    return 0;
}