#include<iostream>

using namespace std;
double patterntwo(int lines2)
{
     cout<<"Please input the number of lines: ";
     cin>>lines2;
     int n1;
     for(n1=0;n1<lines2;n1++){
        for(int n3=lines2;n3>n1;n3--)cout<<"*";
        return cout<<" "<<endl;
     }
        
}