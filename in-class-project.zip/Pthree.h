#include<iostream>

using namespace std;
double Patternthree(int lines3)
{
    int n1;
    cout<<"Please input the number of lines you want: ";
    cin>>lines3;
    for(n1=0;n1<lines3;n1++){
        for(int n2=0;n2<n1;n2++){
            cout<<" ";
        };
        
        for(int n2=lines3;n2>n1;n2--){
            cout<<"*";
        };
    
       return cout<<" "<<endl;
}