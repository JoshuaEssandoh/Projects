#include<iostream>

using namespace std;

double patternone(int lines)
{
    int n1;
    cout<<"Please input the number of lines: ";
    cin>>lines;
    for(n1=0;n1<lines;n1++){
        for(int n2=1;n2<=n1;n2++){
            cout<<"*";
        };
    
        return cout<<" "<<endl;
    }
}