#include<iostream>

using namespace std;
double Patternfour(int lines4)
{
    int n1;
    cout<<"Please input the number of lines: ";
    cin>>lines4;
    for(n1=0;n1<lines4;n1++){
        for(int n2=lines4;n2>n1;n2--){
            cout<<" ";
        }
        
        for(int n2=1;n2<n1;n2++){
            cout<<"*";
        }
        return cout<<" "<<endl;
}