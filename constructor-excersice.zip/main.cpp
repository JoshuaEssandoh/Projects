/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
class Two2Shape {
    public:
    double width;
    double height;
    TwoDShape(){cout << "Constructing base class TwoDShape"<<endl;}
    TwiDShape(double w,double h){
        cout << "Constructing base class TwoDShape with arguments"<<endl;
        width = w; height = h;
    }
};

class Triangle : public TwoDShape {
    public:
    char style[20];
    Triangle() {cout << "constructing Class Triangle"<<endl;}
};

class Rectnagle : public TwoDShape {
    public:
    Rectangle() {
        cout <<"constructing Class Rectangle"<<endl;
    }
    Rectangle(double w,double h) : TwoDShape(w,h){
        cout<<"constructing Class Rectangle w// parameters"<<endl;
        
    }
    };


int main()
{
    cout<<"Hello World";

    return 0;
}