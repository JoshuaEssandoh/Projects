/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
   /*int Multiply1(int n[3]){
        n[0] = 25;
        return n[0]*n[1]*n[2];
    }
    int Multiply2(int n[]){
        return n[0]*n[1]*n[2];
    }
    int Multiply3(int *n){
         return n[0]*n[1]*n[2];
    }
int main()
{
    int *p = 0;
    int a = 5;
    p = &a;
    cout<<*p<<endl;
    cout<<p<<endl;
    p++;
    cout<<*p<<endl;
    
    int nums[3]={1,2,3};
    
    cout<<Multiply1(nums)<<endl;
    cout<<Multiply2(nums)<<endl;
    cout<<Multiply3(nums)<<endl;
    */
    char *SubStr (char *s, char *sub) { 
       int y;
       
        for(int i = 0;*(s + i);i++){
            if(*(s + i) == *(sub + 0)){
                for(int n=0;*(sub + n);n++){
                    if(*(s + i + n) != *(sub + n)){
                        y = 1;
                        break;
                        
                    }
                }
            }
        }
        
        if(y == 1)return "substring … could not be found";
        else return sub;

}

int main () {

  char str[80] = "This Is A Test for substring";

  cout << "Original string: " << str << "\n";

  char *p;

  p=SubStr(str, "for");
  

   cout << "Substring: " << p << "\n";

  return 0;

}
    
    
    
    

  
