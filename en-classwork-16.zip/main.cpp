/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

class Oven{
    public:
    virtual void Cook(){
        cout<<"Oven is Coking..."<<endl;
    } 
};

class MicrowaveOven : public Oven{
    public:
    void Cook(){
        cout<<"Microwave Oven is cooking"<<endl;
    }
};

class ConventionalOven : public Oven{
    public:
    void Cook(){
        cout<<"Gas/Electric Oven is Cooking"<<endl;
    }
};

int main()
{
    Oven O;
    MicrowaveOven M;
    ConventionalOven C;
    
    O.Cook();
    M.Cook();
    C.Cook();

    return 0;
}