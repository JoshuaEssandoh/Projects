/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

int main()
{
    string fun,user;
    
    ifstream File("Information.txt");
    cin>>user;
    while(!myFile.eof()){
  myFile >> Student_Name[i] >> Student_Grade[i];
  i++;
}

    }
    

    return 0;
}