/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <fstream>
#include <iomanip>
#include <algorithm>
using namespace std;

void BestStu(int fingr[3][4],char name1[3][4][25]){
    /*int M, J, Best;
    for(int k = 0; k < 3; k++){
       Best = max({n[k][0], n[k][1],n[k][2], n[k][3]});
       cout << Best << endl;
       }*/
       ofstream myFile1("FinalGrades.txt");
       for(int k = 0;k < 3; k++){
           for(int m = 0;m < 4; m++){
               myFile1 << name1[k][m] <<"  "<< fingr[k][m]<<endl;
           }
       }
       
       char name[12][25];
       int grade[12];
       int i = 0;
       ifstream myFile2("FinalGrades.txt");
       while(!myFile2.eof()){
           myFile2 >> name[i] >> grade[i];
           i++;
       }
    int Best;
    int r;
    Best = max({grade[0],grade[1],grade[2],grade[3],grade[4],grade[5],grade[6],grade[7],grade[8],grade[9],grade[10],grade[11]});
    for(r = 0;r < 12; r++){
        if(Best == grade[r])cout << "The best performing student is: " << name[r] << " with a grade of " << grade[r];
    }
    //For 3 students, make sure to do a for loop that finds the max and prints it, BEFORE you change it to zero and run it again
    
}

int main(){
    


   int figra[3][4];
   char name[3][4][25];
   int grades[3][4][5];
   int i = 0;
   int t = 0;
   int e = 0;
   
   ifstream class1("Class1.txt");
   while(!class1.eof()){
      
       class1 >> name[0][i] >> grades[0][i][0] >> grades[0][i][1] >> grades[0][i][2] >> grades[0][i][3] >> grades[0][i][4];
       
       i++;
   }
   
   
   ifstream class2("Class2.txt");
   while(!class2.eof()){
       
       class2 >> name[1][t] >> grades[1][t][0] >> grades[1][t][1] >> grades[1][t][2] >> grades[1][t][3] >> grades[1][t][4];
       
       t++;
   }
   
   ifstream class3("Class3.txt");
   while(!class3.eof()){
       class3 >> name[2][e] >> grades[2][e][0] >> grades[2][e][1] >> grades[2][e][2] >> grades[2][e][3] >> grades[2][e][4];
       e++;
   }
   
   
   
   for(int k = 0;k < 3;k++){
       for(int m = 0;m < 4;m++){
           figra[k][m] = (((grades[k][m][0] + grades[k][m][1]) / 2)*0.2) + (((grades[k][m][2] + grades[k][m][3]) / 2)*0.1) + (grades[k][m][4]*0.7);
           cout<<name[k][m]<<"    "<<figra[k][m]<<endl;
       }
       
   }
   
   cout<<endl;
   BestStu(figra, name);
    return 0;
}