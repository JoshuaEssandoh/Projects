
#include <iostream>
using namespace std;
int main()
{
    float kilograms,pounds;
    for(kilograms=1;kilograms<=100;kilograms++) 
    {
    cout<<"kilograms:"<<kilograms<<"  "<<"pounds:"<<kilograms*2.2<<"  "<<endl;
    if(kilograms==25) cout<<endl;
    if(kilograms==50) cout<<endl;
    if (kilograms==75) cout<<endl;
    }
    return 0;
    
}

