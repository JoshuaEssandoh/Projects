/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
using namespace std;
void shuf(int array[], int size)
{
      int n;
    char encode = 'a';
    ofstream NewFile("Decoded.txt");
    for(n=0;n<size - 1;n++){
        for(int f=0;f<(size - 1) - n; f++){
            encode=array[f];
            cout<<encode;
            NewFile<<encode;
        }
    }
    
void deco(int array[], int size)
{
    
}
}
int main()
{
    int b = 10;
    int array[b];
    int i=0;
    ifstream MyFile("Array.txt");
    while(!MyFile.eof()){
       MyFile>>array[i];
       //cout<<array[i]<<endl;
       i++;
    }
shuf(array , b);

/*ofstream NewFile("Decoded.txt");
for(int n=0;n<10;n++){
NewFile<< shuf(array, b);
}*/
    return 0;
}
