/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;


class Vehicle {
    public:
     int passengers;
    int fuelcap;
    int mpg;
    int weight;
    int load;
    int range();
    int rangekm();
    
    ~Vehicle();
    string Make;
    string Model;
    string Year;
    Vehicle(string mk,string mo, string yr);
    Vehicle();
};
Vehicle::Vehicle(string mk,string mo,string yr)
{
    Make = mk;
    Model = mo;
    Year= yr;
    cout << Make<<endl<<Model<<endl<<Year<<endl<<" Vehicle object has been created successfully!";
}
Vehicle::~Vehicle(){
    cout <<endl<< "The Vehicle has crashed!!!";
}

Vehicle::Vehicle(){cout<<"Welcome to my world!"<<endl;}



int main()
{
    Vehicle golfcart[5];
    for(int i = 0; i < 5;i++){
        cin>>golfcart[i].Make;
        cin>>golfcart[i].Model;
        cin>>golfcart[i].Year;
        cout<<golfcart[i].Make<<endl<<golfcart[i].Model<<endl<<golfcart[i].Year<<endl;
    }
    return 0;
}
