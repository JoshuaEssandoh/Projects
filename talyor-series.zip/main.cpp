/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <cmath>

using namespace std;
double loop1(int n, double x)
{
    double total=1;
    for(int count=1;count<=n;count++) total=total*x;
    return total;
}
double loop2(double x)
{
    double dec=1;
    for(int count=1;count<=x;count++){
        dec=count*dec;
    }
    return dec;
}
int main()
{

double x;
int n;
cout<<"Please input the n value: ";
cin>>n;
cout<<"Please input the x value: ";
cin>>x;
double out=0;

    for(int m=0;m<=n;m++){
        out=out+loop1(m,x)/loop2(m);
    }
        cout<<out<<" "<<exp(x)<<endl;
    
    
}



