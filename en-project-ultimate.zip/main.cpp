/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <fstream>
#include <iomanip>
#include <algorithm>
using namespace std;

void BestStu(int fingr[2][3][4],char name1[2][3][4][25]){
    
       ofstream myFile1("FinalGrades.txt");
       for(int k = 0;k < 2; k++){
           for(int m = 0;m < 3; m++){
               for(int v = 0;v < 4; v++){
               myFile1 << name1[k][m][v] <<"  "<< fingr[k][m][v]<<endl;
           }
       }
       }
       char name[24][25];
       int grade[24];
       //new arrays so the name and grade directly correlate with the same value
       int i = 0;
       ifstream myFile2("FinalGrades.txt");
       while(!myFile2.eof()){
           myFile2 >> name[i] >> grade[i];
           i++;
       }
    int Best;
    int r;
    Best = max({grade[0],grade[1],grade[2],grade[3],grade[4],grade[5],grade[6],grade[7],grade[8],grade[9],grade[10],grade[11],grade[12],grade[13],grade[14],grade[15],grade[16],grade[17],grade[18],grade[19],grade[20],grade[21],grade[22],grade[23]});
    //The function above calculates the max value of the new grade array ;
    
    for(int q = 0;q < 3; q++){
    for(r = 0;r < 24; r++){
        if(Best == grade[r]){cout << "The 3 best performing students are: " << name[r] << " with a grade of " << grade[r]<<endl;
        grade[r] = 0;
        Best = max({grade[0],grade[1],grade[2],grade[3],grade[4],grade[5],grade[6],grade[7],grade[8],grade[9],grade[10],grade[11],grade[12],grade[13],grade[14],grade[15],grade[16],grade[17],grade[18],grade[19],grade[20],grade[21],grade[22],grade[23]});
        break;
        }
    }
    }
    
}

int main(){
    


   int figra[2][3][4];
   char name[2][3][4][25];
   int grades[2][3][4][5];
   int i = 0;
   int t = 0;
   int e = 0;
   int h = 0;
   int w = 0;
   int o = 0;
   
   ifstream class1("Sch1Class1.txt");
   while(!class1.eof()){
      
       class1 >> name[0][0][i] >> grades[0][0][i][0] >> grades[0][0][i][1] >> grades[0][0][i][2] >> grades[0][0][i][3] >> grades[0][0][i][4];
       
       i++;
   }
   
   
   ifstream class2("Sch1Class2.txt");
   while(!class2.eof()){
       
       class2 >> name[0][1][t] >> grades[0][1][t][0] >> grades[0][1][t][1] >> grades[0][1][t][2] >> grades[0][1][t][3] >> grades[0][1][t][4];
       
       t++;
   }
   
   ifstream class3("Sch1Class3.txt");
   while(!class3.eof()){
       class3 >> name[0][2][e] >> grades[0][2][e][0] >> grades[0][2][e][1] >> grades[0][2][e][2] >> grades[0][2][e][3] >> grades[0][2][e][4];
       e++;
   }
   
   ifstream class4("Sch2Class1.txt");
   while(!class4.eof()){
       class4 >> name[1][0][h] >> grades[1][0][h][0] >> grades[1][0][h][1] >> grades[1][0][h][2] >> grades[1][0][h][3] >> grades[1][0][h][4];
       h++;
   }
   
   ifstream class5("Sch2Class2.txt");
   while(!class5.eof()){
       class5 >> name[1][1][w] >> grades[1][1][w][0] >> grades[1][1][w][1] >> grades[1][1][w][2] >> grades[1][1][w][3] >> grades[1][1][w][4];
       w++;
   }
   
   ifstream class6("Sch2Class3.txt");
   while(!class6.eof()){
       class6 >> name[1][2][o] >> grades[1][2][o][0] >> grades[1][2][o][1] >> grades[1][2][o][2] >> grades[1][2][o][3] >> grades[1][2][o][4];
       o++;
   }
   
   for(int k = 0;k < 2;k++){
       for(int m = 0;m < 3;m++){
           for(int v = 0;v < 4;v++){
           figra[k][m][v] = (((grades[k][m][v][0] + grades[k][m][v][1]) / 2)*0.2) + (((grades[k][m][v][2] + grades[k][m][v][3]) / 2)*0.1) + (grades[k][m][v][4]*0.7);
           cout<<name[k][m][v]<<"    "<<figra[k][m][v]<<endl;
       }
       
   }
}
   cout<<endl;
   BestStu(figra, name);
    return 0;
}