/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
using namespace std;
#include <iostream>
#include<stdlib.h>
int main()
{
    string confirm="yes";
    for(;confirm=="yes";){
    int num1;
    srand(time(0));
    num1 = rand()%10;
    int num2;
    num2 = rand()%10;
    double answer= num1*num2;
    double input;
    cout<<"What is the answer to this problem?: "<<num1<<" * "<<num2<<": ";
    cin>>input;
    ci>>input;
    if(input==answer)
        cout<<"Congradulations!! You are better than Lebron James"<<endl;
    else if(input>answer) cout<<"Too high"<<endl;
    else if(input<answer) cout<<"Too low"<<endl;
    if(answer=0&&answer<=10) cout<<"The answer is between 0 and 10"<<endl;
    else if(answer=11&&answer<=20) cout<<"The answer is between 11 and 20"<<endl;
    else if(answer=21&&answer<=30) cout<<"The answer is between 21 and 30"<<endl;
    else if(answer=31&&answer<=40) cout<<"The answer is between 31 and 40"<<endl;
    else if(answer=41&&answer<=50) cout<<"The answer is between 41 and 50"<<endl;
    else if(answer=51&&answer<=60) cout<<"The answer is between 51 and 60"<<endl;
    else if(answer=61&&answer<=70) cout<<"The answer is between 61 and 70"<<endl;
    else if(answer=71&&answer<=80) cout<<"The answer is between 71 and 80"<<endl;
    else if(answer=81&&answer<=90) cout<<"The answer is between 81 and 90"<<endl;
    else if(answer=91&&answer<=100) cout<<"The answer is between 91 and 100"<<endl;
    cin>>input;
    if(input==answer)
        cout<<"Congradulations!! You are better than Lebron James"<<endl;
    else if(input>answer) cout<<"Too high"<<endl;
    else if(input<answer) cout<<"Too low"<<endl;
    cout<<"Do you want to continue?: "<<endl;
    cin>>confirm;
    
    }
    
    
    
    
}
