/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;


class A{
    public:
    
        virtual void WhichClass(){
            cout<<"Base Class A..."<<endl;
        }
    
};

class B : public A{
    public:
        void WhichClass(){
            cout<<"Derived Class B..."<<endl;
        }
        
};


class C : public B{
    public:
        void WhichClass(){
            cout<<"Derived Class C..."<<endl;
        }
};

class Z{
    public:
    
        virtual void NameClass(){
            cout<<"Base Class Z..."<<endl;
        }
        A a;
};

class D : public A, public Z{
    public:
    
    //void WhichClass();
    void NameClass();
};

class E : public D{
    
};

int main()
{
     Z z;
     z.a.WhichClass();;

    return 0;
}
